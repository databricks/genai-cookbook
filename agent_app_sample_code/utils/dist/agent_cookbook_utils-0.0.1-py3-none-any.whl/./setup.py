from setuptools import setup, find_packages

setup(
    name="agent_cookbook_utils",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "mlflow",
        "pandas",
        "pydantic",
        "databricks-sdk",
        "pyyaml",
        "langchain-text-splitters==0.2.0",
        "transformers==4.41.1",
        "tiktoken==0.7.0",
        "databricks-vectorsearch",
        "databricks-agents",
    ],
    author="Databricks",
    author_email="",
    description="Utility functions for Databricks Agent Applications",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
